# Agency OS Pipelines v2

This package contains 20 production pipeline files for the Agency OS locked factory workflow.

Core rule:

> Build once. Lock the source. Duplicate safely. Customize through approved client layers.

Flow:

Factory Overview → Intake → Template Selection → Locked Source Rules → Theme Tokens → Components → Content → Assets → Page Build → Responsive → Accessibility → SEO → Performance → QA → Review → Deploy → Post-Launch → Change Requests → Staff Training → Automation
