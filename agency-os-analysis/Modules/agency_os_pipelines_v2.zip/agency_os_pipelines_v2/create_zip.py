from pathlib import Path
import zipfile

source_dir = Path(__file__).resolve().parent
zip_path = source_dir.parent / "agency_os_pipelines_v2.zip"

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for file_path in source_dir.rglob("*"):
        zipf.write(file_path, file_path.relative_to(source_dir.parent))

print(f"Created: {zip_path}")
