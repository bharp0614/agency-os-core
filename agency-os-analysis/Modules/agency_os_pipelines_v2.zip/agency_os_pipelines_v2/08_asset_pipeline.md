# 08 — Asset Pipeline

## Purpose

This file defines the Asset Pipeline stage of the Agency OS locked factory production line.

## Factory Principle

The locked factory is the source of truth. Staff should work inside client copies and avoid editing the factory unless a change request is approved.

## Inputs

- Client brief
- Approved template
- Theme tokens
- Component rules
- Content requirements
- Asset folder
- QA checklist

## Process

1. Confirm the project is in the correct client folder.
2. Use approved factory templates and components.
3. Customize through content, assets, and theme tokens.
4. Avoid direct edits to locked source files.
5. Run the checklist for this production stage.
6. Save a report in the client reports folder.
7. Submit for review before moving to the next stage.

## Staff Can Edit

```txt
clients/client-name/content/
clients/client-name/theme.css
clients/client-name/assets/
clients/client-name/pages/
clients/client-name/config/
clients/client-name/reports/
```

## Staff Cannot Edit Without Approval

```txt
factory/core/
factory/components/
factory/templates/
factory/utilities/
factory/design-tokens/
factory/scripts/
```

## Checklist

- Factory source was not modified.
- Client copy is clearly separated.
- Work matches the selected template.
- Theme tokens are used instead of hard-coded styling.
- Approved components are reused.
- Placeholder content is removed.
- Mobile layout is checked.
- Accessibility basics are checked.
- SEO basics are checked.
- QA notes are documented.

## Output

```txt
clients/client-name/reports/asset_pipeline.md
```

## Done Means

This pipeline is complete when the output exists, the checklist is reviewed, and the work is ready for the next production stage.
