"""
Agency OS Automation Pipeline

Creates a standard client project folder from the locked factory workflow.
This script does not modify factory source files.
"""

from pathlib import Path
import json
from datetime import datetime

ROOT = Path(__file__).resolve().parent
CLIENTS_DIR = ROOT / "clients"

def slugify(name: str) -> str:
    return name.lower().strip().replace(" ", "-").replace("_", "-")

def create_client_project(client_name: str, template_name: str = "service-business-site") -> Path:
    client_slug = slugify(client_name)
    client_dir = CLIENTS_DIR / client_slug

    if client_dir.exists():
        raise FileExistsError(f"Client project already exists: {client_dir}")

    folders = [
        "content", "assets/logos", "assets/images", "assets/icons",
        "pages", "components", "config", "reports"
    ]

    for folder in folders:
        (client_dir / folder).mkdir(parents=True, exist_ok=True)

    (client_dir / "00_client_brief.md").write_text(f"""# Client Brief: {client_name}

Template selected: {template_name}
Created: {datetime.now().isoformat(timespec='seconds')}

## Business Name
## Industry
## Primary Offer
## Target Audience
## Required Pages
## Brand Colors
## Fonts
## Calls to Action
## Notes
""", encoding="utf-8")

    (client_dir / "theme.css").write_text("""@theme {
  --color-primary: #764abc;
  --color-secondary: #414387;
  --color-accent: #f0456f;

  --font-display: "Poppins", sans-serif;
  --font-body: "Inter", sans-serif;
}
""", encoding="utf-8")

    metadata = {
        "client_name": client_name,
        "client_slug": client_slug,
        "template_name": template_name,
        "created": datetime.now().isoformat(timespec="seconds"),
        "factory_locked": True,
    }

    (client_dir / "config/project.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return client_dir

if __name__ == "__main__":
    project = create_client_project("Example Client")
    print(f"Created client project: {project}")
