# Agency OS Research Engine v1

This starter research engine turns full-page website screenshots into a structured research database.

## What Version 1 extracts

1. Page intent
2. Color system
3. Hero type
4. CTA strategy
5. Section order
6. Components detected
7. Trust signals

## Folder structure

```txt
agency_os_research_engine_v1/
  input/       Put screenshots here
  output/      One JSON file per screenshot
  database/    Combined CSV, JSON, and pattern summary
```

## Run order

```bash
python 01_analyze_images.py
python 03_build_database.py
python 04_pattern_summary.py
```

## Important

This version runs in mock mode first. It proves the pipeline works before an AI vision API is connected.
