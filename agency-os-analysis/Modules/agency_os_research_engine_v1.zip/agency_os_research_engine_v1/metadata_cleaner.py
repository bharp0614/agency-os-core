DEFAULT_RECORD = {
    "file_name": "",
    "page_intent": "Unknown",
    "color_system": "Unknown",
    "primary_color": "Unknown",
    "secondary_colors": [],
    "hero_type": "Unknown",
    "cta_text": [],
    "section_order": [],
    "components_detected": [],
    "trust_signals": [],
    "typography_style": "Unknown",
    "imagery_style": "Unknown",
    "visual_density": "Unknown",
    "notes": ""
}

LIST_FIELDS = {
    "secondary_colors",
    "cta_text",
    "section_order",
    "components_detected",
    "trust_signals"
}

def normalize_record(raw: dict) -> dict:
    clean = DEFAULT_RECORD.copy()

    for key in clean:
        value = raw.get(key, clean[key])

        if key in LIST_FIELDS:
            if value is None:
                value = []
            elif isinstance(value, str):
                value = [value]
            elif not isinstance(value, list):
                value = []
        else:
            if value is None:
                value = clean[key]
            elif isinstance(value, list):
                value = ", ".join(str(item) for item in value)
            else:
                value = str(value)

        clean[key] = value

    for key, value in raw.items():
        if key.startswith("_"):
            clean[key] = value

    return clean
