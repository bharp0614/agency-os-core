# Website Screenshot Analysis Prompt

Analyze this full-page website screenshot for Agency OS design research.

Return only valid JSON.

Do not include markdown.
Do not describe the image casually.
Do not invent unseen sections.
Use "Unknown" when uncertain.
Use empty arrays when no items are visible.

Extract:

{
  "file_name": "",
  "page_intent": "",
  "color_system": "",
  "primary_color": "",
  "secondary_colors": [],
  "hero_type": "",
  "cta_text": [],
  "section_order": [],
  "components_detected": [],
  "trust_signals": [],
  "typography_style": "",
  "imagery_style": "",
  "visual_density": "",
  "notes": ""
}

Allowed page_intent values:
- Lead Generation
- Quote Request
- Booking
- Product Sale
- Trust Building
- Recruiting
- Education
- Portfolio
- Other
- Unknown

Allowed hero_type values:
- Hero + CTA
- Hero + Form
- Hero + Image
- Hero + Video
- Split Hero
- Product Hero
- Unknown
