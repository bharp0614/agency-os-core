from pathlib import Path
import json
import hashlib
from datetime import datetime

INPUT_DIR = Path("input")
OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}

def image_id(image_path: Path) -> str:
    raw = image_path.read_bytes()
    return hashlib.sha256(raw).hexdigest()[:12]

def mock_analyze_image(image_path: Path) -> dict:
    """
    Mock analyzer.

    This proves the pipeline works before AI vision is connected.
    Later, replace this function with a real model call.
    """
    name = image_path.stem.lower()

    if "roof" in name:
        page_intent = "Quote Request"
        color_system = "Yellow + Black + White"
        components = ["Header", "Hero", "CTA", "Service Cards", "Contact Form", "Footer"]
    elif "construction" in name or "contractor" in name:
        page_intent = "Lead Generation"
        color_system = "Yellow + Black + White"
        components = ["Header", "Hero", "CTA", "Service Cards", "Stats", "Footer"]
    elif "restaurant" in name:
        page_intent = "Booking"
        color_system = "Warm Neutral"
        components = ["Header", "Hero", "Menu", "Gallery", "Booking CTA", "Footer"]
    elif "saas" in name or "software" in name:
        page_intent = "Product Sale"
        color_system = "Blue + White + Gray"
        components = ["Header", "Hero", "Feature Cards", "Pricing", "CTA", "Footer"]
    else:
        page_intent = "Unknown"
        color_system = "Unknown"
        components = []

    return {
        "file_name": image_path.name,
        "page_intent": page_intent,
        "color_system": color_system,
        "primary_color": "Unknown",
        "secondary_colors": [],
        "hero_type": "Unknown",
        "cta_text": [],
        "section_order": [],
        "components_detected": components,
        "trust_signals": [],
        "typography_style": "Unknown",
        "imagery_style": "Unknown",
        "visual_density": "Unknown",
        "notes": "Mock analysis only. Connect AI vision for real extraction."
    }

def main():
    if not INPUT_DIR.exists():
        INPUT_DIR.mkdir()

    images = [
        p for p in INPUT_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    ]

    if not images:
        print("No screenshots found in input/. Add .png, .jpg, .jpeg, or .webp files.")
        return

    for image_path in images:
        record = mock_analyze_image(image_path)
        record["_source_path"] = str(image_path)
        record["_image_id"] = image_id(image_path)
        record["_analyzed_at"] = datetime.utcnow().isoformat() + "Z"

        output_path = OUTPUT_DIR / f"{image_path.stem}.json"
        output_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
        print(f"Analyzed: {image_path.name} -> {output_path}")

    print(f"Done. Created {len(images)} JSON records in output/.")

if __name__ == "__main__":
    main()
