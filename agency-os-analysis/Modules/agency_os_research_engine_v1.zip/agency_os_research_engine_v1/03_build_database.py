from pathlib import Path
import json
import csv
from metadata_cleaner import normalize_record

OUTPUT_DIR = Path("output")
DATABASE_DIR = Path("database")
DATABASE_DIR.mkdir(exist_ok=True)

def main():
    json_files = sorted(OUTPUT_DIR.glob("*.json"))

    if not json_files:
        print("No JSON records found in output/. Run 01_analyze_images.py first.")
        return

    records = []

    for path in json_files:
        raw = json.loads(path.read_text(encoding="utf-8"))
        records.append(normalize_record(raw))

    json_path = DATABASE_DIR / "research.json"
    json_path.write_text(json.dumps(records, indent=2), encoding="utf-8")

    csv_path = DATABASE_DIR / "research.csv"
    fieldnames = list(records[0].keys())

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for row in records:
            clean_row = {
                key: json.dumps(value) if isinstance(value, list) else value
                for key, value in row.items()
            }
            writer.writerow(clean_row)

    print(f"Saved database JSON: {json_path}")
    print(f"Saved database CSV: {csv_path}")
    print(f"Total records: {len(records)}")

if __name__ == "__main__":
    main()
