from pathlib import Path
import json
from collections import Counter

DATABASE_PATH = Path("database/research.json")
SUMMARY_PATH = Path("database/patterns.md")

FIELDS_TO_COUNT = [
    "page_intent",
    "color_system",
    "primary_color",
    "hero_type",
    "typography_style",
    "imagery_style",
    "visual_density"
]

LIST_FIELDS_TO_COUNT = [
    "secondary_colors",
    "cta_text",
    "section_order",
    "components_detected",
    "trust_signals"
]

def count_field(records, field):
    return Counter(record.get(field, "Unknown") for record in records)

def count_list_field(records, field):
    counter = Counter()

    for record in records:
        values = record.get(field, [])
        if isinstance(values, list):
            counter.update(values)

    return counter

def render_counter(title, counter, limit=20):
    lines = [f"## {title}", ""]
    if not counter:
        lines.append("_No data._")
        lines.append("")
        return lines

    total = sum(counter.values())

    for value, count in counter.most_common(limit):
        percent = (count / total) * 100 if total else 0
        lines.append(f"- {value}: {count} ({percent:.1f}%)")

    lines.append("")
    return lines

def main():
    if not DATABASE_PATH.exists():
        print("No database found. Run 03_build_database.py first.")
        return

    records = json.loads(DATABASE_PATH.read_text(encoding="utf-8"))

    lines = [
        "# Agency OS Pattern Summary",
        "",
        f"Total screenshots analyzed: {len(records)}",
        ""
    ]

    for field in FIELDS_TO_COUNT:
        lines.extend(render_counter(field.replace("_", " ").title(), count_field(records, field)))

    for field in LIST_FIELDS_TO_COUNT:
        lines.extend(render_counter(field.replace("_", " ").title(), count_list_field(records, field)))

    SUMMARY_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(f"Saved summary: {SUMMARY_PATH}")

if __name__ == "__main__":
    main()
