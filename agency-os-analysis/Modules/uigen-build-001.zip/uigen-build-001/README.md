# UIGEN Build 001

Development factory scaffold for a reusable, theme-driven UI system.

## Purpose

UIGEN Build 001 is the first implementation layer for the internal engineering factory.

It stores reusable components, style packs, tokens, layouts, prompts, validation rules, and factory definitions used to mass-produce landing pages and local business card websites.

## Core Rule

Everything begins in `dev-factory/`.

Nothing moves to `stable-core/` until it is tested, documented, token-driven, and approved.

## Promotion Flow

```text
dev-factory
  ↓ test
stable-core
  ↓ export package
Agency OS Core
  ↓ client repo
hosting platform
```

## Start Here

1. `docs/NEXT_INSTRUCTIONS.md`
2. `docs/BUILD_PROTOCOL.md`
3. `docs/STYLE_FACTORY_RULES.md`
4. `registry/component-manifest.json`
5. `registry/factory-manifest.json`
