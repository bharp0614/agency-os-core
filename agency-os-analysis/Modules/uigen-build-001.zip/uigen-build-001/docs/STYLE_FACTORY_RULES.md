# Style Factory Rules

## Main Principle

Components stay reusable.

Styles change through tokens and style packs.

## Never Do This

```tsx
<div className="bg-purple-500 text-white rounded-xl">
```

## Prefer This

```tsx
<div className="bg-[var(--surface)] text-[var(--text)] rounded-[var(--radius-lg)]">
```

## Style Pack Owns

- colors
- typography
- spacing
- radius
- shadows
- glow
- motion
- visual density

## Component Owns

- structure
- accessibility
- behavior
- slots
- variants
- responsive layout

## Factory Owns

- which components are used
- which page sections are required
- what content fields are needed
- how output is assembled
- what validation must pass
