# Architecture Decisions

## Decision 001 — UIGEN Is the Factory

UIGEN is the internal factory for reusable UI components, templates, tokens, prompts, and style systems.

## Decision 002 — Agency OS Core Is Not the Factory

Agency OS Core consumes approved UIGEN outputs. It does not own the reusable design system.

## Decision 003 — Client Websites Stay Separate

Live client websites are isolated in their own repositories or hosting projects.

## Decision 004 — Client-Facing Systems Stay Separate

Client portals, builders, sign-ins, approvals, and self-service tools must be separate from Agency OS Core and UIGEN.

## Decision 005 — Everything Starts in Development

Build 001 is development-only. Stable assets are promoted later.
