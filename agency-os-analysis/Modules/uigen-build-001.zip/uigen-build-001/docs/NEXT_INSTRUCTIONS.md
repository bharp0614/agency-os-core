# Next Instructions

## Step 1 — Copy Into UIGEN

Copy this scaffold into the UIGEN repository.

Recommended branch:

```bash
git checkout -b uigen-build-001-dev-factory
```

## Step 2 — Keep It Development Only

Do not wire this directly into production.

This is the first development factory.

## Step 3 — Build the First Vertical Slice

Build this chain first:

```text
style tokens
↓
theme object
↓
Button
↓
Card
↓
Hero
↓
Local Business Card Site template
```

## Step 4 — Validate the Pattern

Before adding all 30 components, confirm:

- theme tokens work
- components do not hardcode design values
- metadata exists
- examples exist
- content is replaceable
- client data is not present
- the factory can produce one complete page

## Step 5 — Duplicate Style Rules Later

After Style 001 works, create new style packs only.

Do not duplicate the component system.
