# UIGEN Build Protocol

## Classification

```text
Name: UIGEN Build 001
Type: Development Factory
Status: Experimental
Production Use: Not Approved
Client Access: Never
```

## Promotion Rules

A file may move from `dev-factory/` to `stable-core/` only when it meets these conditions:

1. No hardcoded client content
2. No hardcoded colors
3. No hardcoded typography
4. Uses theme tokens
5. Has typed props or schema metadata
6. Includes example usage
7. Includes accessibility notes
8. Has responsive behavior
9. Has no secrets
10. Has documentation
