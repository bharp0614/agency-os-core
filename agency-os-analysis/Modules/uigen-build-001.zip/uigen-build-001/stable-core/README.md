# Stable Core

Approved reusable UIGEN assets only.

Nothing enters this folder directly.

Promotion path:

```text
dev-factory → validation → review → stable-core
```
