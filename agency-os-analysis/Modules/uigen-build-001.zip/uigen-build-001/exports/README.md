# Exports

Approved factory outputs will be placed here before being consumed by Agency OS Core.

Do not export development work until it passes validation and review.
