# Landing Page Factory

## Purpose

Generate campaign-focused landing pages.

## Status

Development only.

Build this after the Local Business Card Site Factory works.
