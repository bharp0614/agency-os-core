# Local Business Card Site Factory

## Purpose

Generate a simple one-page website for a local business.

## Required Sections

1. Hero
2. Services / Features
3. Testimonials
4. Contact CTA
5. Footer

## Required Truth Source Fields

- business_name
- services
- phone
- service_area
- primary_cta

## Output

A composable one-page site package that can be exported to Agency OS Core or a separate client website repository.

## Status

Development only.
