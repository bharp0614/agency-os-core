# card

## Purpose

Reusable surface container for content, features, pricing, and dashboard panels.

## Status

Stubbed for UIGEN Build 001.

## Build Requirements

- Must use theme tokens.
- Must avoid client-specific content.
- Must include accessible markup.
- Must include responsive behavior.
- Must include usage examples before promotion.
