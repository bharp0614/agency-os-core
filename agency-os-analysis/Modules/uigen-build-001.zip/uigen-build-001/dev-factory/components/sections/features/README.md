# features

## Purpose

Reusable benefits or services grid.

## Status

Stubbed for UIGEN Build 001.

## Build Requirements

- Must use theme tokens.
- Must avoid client-specific content.
- Must include accessible markup.
- Must include responsive behavior.
- Must include usage examples before promotion.
