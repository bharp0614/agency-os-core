# hero

## Purpose

Primary page introduction section.

## Status

Stubbed for UIGEN Build 001.

## Build Requirements

- Must use theme tokens.
- Must avoid client-specific content.
- Must include accessible markup.
- Must include responsive behavior.
- Must include usage examples before promotion.
