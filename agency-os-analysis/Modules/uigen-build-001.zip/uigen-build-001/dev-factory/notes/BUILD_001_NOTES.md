# Build 001 Notes

Use this file to capture what works, what breaks, and what needs to change before promotion.
