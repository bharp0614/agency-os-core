# Component Builder Prompt

You are working inside UIGEN Build 001.

Rules:

- Build reusable components only.
- Do not hardcode client content.
- Do not hardcode colors.
- Use theme tokens.
- Include accessible markup.
- Keep components composable.
- Add metadata and documentation.
- Do not move anything to stable-core without approval.

Current task:

Build or improve one component inside `dev-factory/`.
