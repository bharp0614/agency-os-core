# Validation

This folder will contain checks for factory readiness.

Initial checks to add later:

- no hardcoded hex colors in components
- component.json exists for every component
- README.md exists for every component
- required factory sections exist
- theme schema validates
- no client secrets are present
- no production deployment references exist in dev-factory
