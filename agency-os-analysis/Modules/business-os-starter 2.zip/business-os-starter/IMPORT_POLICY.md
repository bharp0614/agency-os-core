# Import Package Policy

## Principle

The project changes through approved packages, not uncontrolled live edits.

Agents may:

- analyze files
- recommend changes
- generate package proposals
- validate package structure
- explain risks
- produce review reports

Agents may not:

- directly edit production files
- silently overwrite existing files
- move files without approval
- introduce client data into UIGEN
- merge public brand assets without classification

## Import Flow

```text
External workspace
    ↓
Create change package ZIP
    ↓
Import staging
    ↓
Validate manifest
    ↓
Validate schemas
    ↓
Review affected systems
    ↓
Approve or reject
    ↓
Apply package
    ↓
Update registry and decision log
```

## Required Package Files

```text
change-package.zip
│
├── manifest.json
├── README.md
├── files/
├── docs/
└── validation-notes.md
```

## Manifest Requirements

Every package must declare:

- package name
- package type
- owner system
- affected systems
- whether client access is involved
- whether UIGEN is affected
- whether production deployment is affected
- approval status
