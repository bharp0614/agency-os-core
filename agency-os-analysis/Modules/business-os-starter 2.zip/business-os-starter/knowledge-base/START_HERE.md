# Start Here

This knowledge base explains how to continue work across new chats.

## Source of Truth

Use these files first:

1. MASTER_ARCHITECTURE.md
2. IMPORT_POLICY.md
3. WORKFLOW.md
4. registry/systems.json
5. systems/*.md

## Standing Rules

- Business OS is private.
- UIGEN is internal only.
- Agency OS Core may later expose controlled client entry points.
- Brittany Harp and Indy CoCreator remain separate public brands.
- Agents do not directly edit production files.
- Changes enter through reviewed import packages.
