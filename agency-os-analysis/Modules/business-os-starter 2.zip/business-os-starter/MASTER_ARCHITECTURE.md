# Master Architecture

## Purpose

This document defines the starting architecture for the company ecosystem.

The goal is to support multiple brands, products, and operational systems while keeping each part isolated enough that one failure does not break the whole machine.

## Top-Level Model

```text
Parent Company
│
├── Business OS
│   ├── Company operations
│   ├── Documentation
│   ├── Security rules
│   ├── Internal agents
│   ├── Import package policy
│   └── System registries
│
├── UIGEN
│   ├── Internal-only product
│   ├── Component library
│   ├── Templates
│   ├── Building blocks
│   ├── Agent patterns
│   └── Design system
│
├── Agency OS Core
│   ├── Client production system
│   ├── Internal operations
│   ├── Project delivery
│   ├── Deployment workflows
│   └── Future controlled client entry point
│
├── Brittany Harp
│   ├── Consulting brand
│   ├── AI integration
│   ├── Software engineering
│   └── Technical documentation
│
└── Indy CoCreator
    ├── Community-facing agency brand
    ├── Affordable websites
    ├── Free downloads
    ├── Knowledge base
    └── Small business resources
```

## Boundary Rules

1. UIGEN is never client-facing.
2. Agency OS Core may support client-facing entry points later, but only through controlled interfaces.
3. Public brands stay separately marketed and separately branded.
4. Business OS remains private.
5. Agents do not directly edit production files.
6. All changes enter through reviewed import packages.
7. Files communicate through manifests, registries, schemas, dependency maps, and documentation.
