# Decisions Log

Use this file to record important architecture decisions.

## Format

```text
Date:
Decision:
Reason:
Affected Systems:
Status:
```

## Initial Decisions

### Decision 001 — Use Import Packages Only

Date: Initial setup  
Decision: Production files are changed only through reviewed import packages.  
Reason: Prevent uncontrolled agent edits and preserve owner approval.  
Affected Systems: Business OS, UIGEN, Agency OS Core, public brands  
Status: Active

### Decision 002 — UIGEN Is Internal Only

Date: Initial setup  
Decision: UIGEN never accepts client access, client data, or client projects.  
Reason: Protect reusable engineering assets and intellectual property.  
Affected Systems: UIGEN, Agency OS Core  
Status: Active

### Decision 003 — Agency OS Core May Have Client Entry Points Later

Date: Initial setup  
Decision: Agency OS Core may eventually expose controlled client portals, forms, or status views.  
Reason: Client interaction belongs in production operations, not UIGEN.  
Affected Systems: Agency OS Core, Indy CoCreator, Brittany Harp  
Status: Active
