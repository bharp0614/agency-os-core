# New Chat Starter

Copy this into a new chat:

We are working on the Business OS setup.

Use these standing rules:
- Parent company owns the ecosystem.
- Business OS is private.
- UIGEN is internal only and never client-facing.
- Agency OS Core is internal production and may later expose controlled client entry points.
- Brittany Harp and Indy CoCreator are separate public brands with separate marketing.
- Agents may analyze, recommend, validate, and package changes.
- Agents may not directly edit production files.
- All changes enter through reviewed import packages.

Current task:
[WRITE TASK HERE]

System being worked on:
[Business OS / UIGEN / Agency OS Core / Brittany Harp / Indy CoCreator]

Expected output:
[Documentation / package manifest / workflow / agent definition / architecture map]
