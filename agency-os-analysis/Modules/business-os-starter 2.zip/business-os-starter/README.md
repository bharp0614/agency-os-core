# Business OS Starter

This repository is the starting container for the parent-company operating system.

It documents the private company architecture, systems, rules, registries, import-package policy, and knowledge base used to keep UIGEN, Agency OS Core, Brittany Harp, and Indy CoCreator aligned without mixing their responsibilities.

## Core Systems

- Business OS: private company operations and source of truth
- UIGEN: internal-only product for components, templates, agents, and reusable building blocks
- Agency OS Core: internal production and client-operations platform; may expose controlled client entry points later
- Brittany Harp: public consulting and AI/software engineering brand
- Indy CoCreator: public community and affordable website brand

## Operating Rule

Agents may analyze, plan, recommend, validate, and package changes.

Agents do not directly edit production files.

All changes enter through reviewed import packages.
