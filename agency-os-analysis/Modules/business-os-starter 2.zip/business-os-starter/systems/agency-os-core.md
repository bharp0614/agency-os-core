# Agency OS Core

## Role

Agency OS Core is the internal production and client-operations platform.

## Access

Internal by default. May expose controlled client entry points later.

## Owns

- Client project workflows
- Production delivery
- Client operations
- Deployment workflows
- Future client portal, forms, or status views
- Approved use of UIGEN outputs

## Rules

- Client-facing access must be controlled.
- Agency OS Core may consume approved UIGEN assets.
- Agency OS Core must not expose UIGEN internals.
