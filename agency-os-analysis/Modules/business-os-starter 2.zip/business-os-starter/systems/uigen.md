# UIGEN

## Role

UIGEN is the internal-only product for reusable engineering assets.

## Access

Internal only. Never client-facing.

## Owns

- Components
- Templates
- Building blocks
- Design system
- Agent patterns
- Engineering standards
- Reusable documentation patterns

## Rules

- No client data
- No client projects
- No client portal
- No public user access
- Approved outputs may be consumed by Agency OS Core
