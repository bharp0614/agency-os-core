# Business OS

## Role

Business OS is the private operating layer of the parent company.

It contains company rules, architecture, registries, internal workflows, security boundaries, documentation, and agent operating policy.

## Access

Private only.

## Owns

- Master architecture
- Import policy
- Registries
- Schemas
- Decision logs
- Company-wide documentation
- Internal agent policy
- Security boundaries

## Does Not Own

- Public brand messaging
- Client-facing website content
- Client project deliverables
- UIGEN component source
