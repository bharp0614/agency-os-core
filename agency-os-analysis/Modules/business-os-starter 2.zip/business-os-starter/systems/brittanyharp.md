# Brittany Harp

## Role

Public professional brand for AI consulting, software engineering, system architecture, automation, and technical development.

## Access

Public website and marketing channels.

## Audience

- Companies
- Organizations
- Technical decision-makers
- Businesses seeking AI integration or custom software

## Brand Direction

Professional, technical, analytical, architecture-focused.
