# Indy CoCreator

## Role

Public community-facing brand for affordable websites, free resources, education, and practical support for small business owners.

## Access

Public website and marketing channels.

## Audience

- Small businesses
- Local service companies
- Contractors
- Community organizations
- Entrepreneurs

## Brand Direction

Helpful, approachable, practical, affordable, educational.
