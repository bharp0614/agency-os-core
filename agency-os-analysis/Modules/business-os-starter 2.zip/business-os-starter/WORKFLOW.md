# Working Workflow

## Daily Working Model

1. Use ChatGPT for planning, reasoning, documentation, package design, and review.
2. Use GitHub or local files as the source of truth.
3. Keep Business OS as the architecture and rules layer.
4. Build one system at a time.
5. Bring changes in through import packages.

## New Chat Workflow

When opening a new chat, provide:

1. The current task.
2. The system being worked on.
3. The relevant Business OS files.
4. The rule: no direct production file edits.
5. The expected output.

Example:

```text
We are working inside the Business OS architecture.

Current system: Agency OS Core.
Task: define the client intake workflow.
Rules:
- UIGEN is internal only.
- Agency OS Core may have client entry points later.
- Agents may analyze and generate package proposals, but not directly edit production files.
- Changes enter through reviewed import packages.

Use MASTER_ARCHITECTURE.md, IMPORT_POLICY.md, and registry files as source of truth.
```

## Build Order

```text
1. Business OS root
2. Import package system
3. Agent rules
4. UIGEN
5. Agency OS Core
6. brittanyharp.com
7. indycocreator.com
```
